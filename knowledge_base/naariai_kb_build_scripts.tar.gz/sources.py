# Verified source registry — URLs only.
# Every URL below was actually retrieved and read during this build.
# Do not add an entry here that has not been opened and checked.

SOURCES = {
    "WHO_PCOS": "https://www.who.int/news-room/fact-sheets/detail/polycystic-ovary-syndrome",
    "WHO_MENST": "https://www.who.int/news-room/fact-sheets/detail/menstrual-health",
    "WHO_ANAEMIA": "https://www.who.int/news-room/fact-sheets/detail/anaemia",
    "WHO_ANC": "https://www.who.int/news/item/07-11-2016-new-guidelines-on-antenatal-care-for-a-positive-pregnancy-experience",
    "WHO_MMR": "https://www.who.int/news-room/fact-sheets/detail/maternal-mortality",
    "WHO_IYCF": "https://www.who.int/news-room/fact-sheets/detail/infant-and-young-child-feeding",
    "WHO_PNC": "https://www.who.int/news/item/30-03-2022-who-urges-quality-care-for-women-and-newborns-in-critical-first-weeks-after-childbirth",
    "WHO_PRETERM": "https://www.who.int/news-room/fact-sheets/detail/preterm-birth",
    "WHO_PREECL": "https://www.who.int/news-room/fact-sheets/detail/pre-eclampsia",
    "PCOS_GL_2023": "https://academic.oup.com/jcem/article/108/10/2447/7242360",
    "ATA_2026": "https://www.thyroid.org/new-ata-guidelines-for-thyroid-disease-in-preconception-pregnancy-and-postpartum/",
}
