#!/usr/bin/env python3
"""Assemble the NaariAI English FAQ dataset into a 6-column CSV."""
import csv, importlib, sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sources import SOURCES

# (module_name, category)
MANIFEST = [
    ("p01_early",      "Pregnancy & Maternal Health"),
    ("p02_trimester",  "Pregnancy & Maternal Health"),
    ("p03_visits",     "Pregnancy & Maternal Health"),
    ("p04_symptoms",   "Pregnancy & Maternal Health"),
    ("p05_nutrition",  "Pregnancy & Maternal Health"),
    ("p06_delivery",   "Pregnancy & Maternal Health"),
    ("p07_postnatal",  "Pregnancy & Maternal Health"),
    ("p08_breastfeed", "Pregnancy & Maternal Health"),
    ("p09_danger",     "Pregnancy & Maternal Health"),
    ("c01_whatis",     "PCOS & Hormonal Health"),
    ("c02_diagnosis",  "PCOS & Hormonal Health"),
    ("c03_periods",    "PCOS & Hormonal Health"),
    ("c04_metabolic",  "PCOS & Hormonal Health"),
    ("c05_skinhair",   "PCOS & Hormonal Health"),
    ("c06_thyroid",    "PCOS & Hormonal Health"),
    ("c07_lifestyle",  "PCOS & Hormonal Health"),
    ("c08_myths",      "PCOS & Hormonal Health"),
]

def main(out_path):
    rows, counters, problems = [], {}, []
    seen_questions = {}
    next_id = 0

    for mod_name, category in MANIFEST:
        try:
            mod = importlib.import_module(mod_name)
        except ModuleNotFoundError:
            continue  # chunk not written yet
        for sub, question, answer, src_key in mod.ROWS:
            if src_key not in SOURCES:
                problems.append(f"UNKNOWN SOURCE KEY '{src_key}' in {mod_name}: {question[:50]}")
                continue
            norm_q = " ".join(question.lower().split())
            if norm_q in seen_questions:
                problems.append(f"DUPLICATE QUESTION in {mod_name} (also {seen_questions[norm_q]}): {question[:60]}")
            seen_questions[norm_q] = mod_name

            counters[category] = counters.get(category, 0) + 1
            next_id += 1
            rows.append({
                "id": next_id,
                "category": category,
                "sub_category": sub,
                "question": question,
                "answer": answer,
                "source": SOURCES[src_key],
            })

    with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["id", "category", "sub_category", "question", "answer", "source"])
        w.writeheader()
        w.writerows(rows)

    print(f"Wrote {len(rows)} rows -> {out_path}")
    for cat, n in counters.items():
        print(f"  {cat}: {n}")
    print("\nRows per sub-category:")
    subs = {}
    for r in rows:
        subs[(r['category'], r['sub_category'])] = subs.get((r['category'], r['sub_category']), 0) + 1
    for (cat, sub), n in subs.items():
        print(f"  [{cat}] {sub}: {n}")
    print("\nSources actually used:", len({r['source'] for r in rows}), "of", len(SOURCES))
    if problems:
        print("\n!! PROBLEMS FOUND !!")
        for p in problems:
            print("  -", p)
    else:
        print("\nNo duplicate questions, no unknown source keys.")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "naariai_faq_english.csv")
